<?php
session_start();
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{

if(isset($_POST['submit']))	
{
$profid=$_SESSION['id'];
$course=$_POST['course'];
$q=mysql_query("select * from course where id = $course");
$r=mysql_fetch_array($q);
$coursename = $r['courseName'];
$preference1 = $_POST['preference1'];
$preference2 = $_POST['preference2'];
$preference3 = $_POST['preference3'];
$ret=mysql_query("insert into slots(profid,coursename,courseid,preference1,preference2,preference3) values('$profid','$coursename','$course','$preference1','$preference2','$preference3')");
if($ret)
{
$_SESSION['msg']="Slots submitted Successfully !!";
}
else
{
  $_SESSION['msg']="Not submitted: Try again!";
}
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Course Slots</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>

<body>
<?php include('includes/header.php');?>
    <!-- LOGO HEADER END-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php');
}
 ?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Course slots</h1>
                    </div>
                </div>
                <div class="row" >
                  <div class="col-md-3"></div>
                    <div class="col-md-6">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                          Course Enroll
                        </div>
<font color="green" align="center"><?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></font>
<?php $sql=mysql_query("select * from faculty where id = '".$_SESSION['id']."'");
$cnt=1;
while($row=mysql_fetch_array($sql))
{ ?>

                        <div class="panel-body">
                       <form name="dept" method="post" enctype="multipart/form-data">
   <div class="form-group">
    <label for="profname">Proffesor Name  </label>
    <input type="text" class="form-control" id="profname" name="profname" value="<?php echo htmlentities($row['profName']);?>"  />
  </div>

 
<div class="form-group">
    <label for="Course">Course  </label>
    <select class="form-control" name="course" id="course" required="required">
   <option value="">Select Course</option>   
   <?php 
$sql=mysql_query("select * from course where profid = '".$_SESSION['id']."'");
while($row=mysql_fetch_array($sql))
{
?>
<option value="<?php echo htmlentities($row['id']);?>"><?php echo htmlentities($row['courseName']);?></option>
<?php } ?>
    </select> 
    <span id="course-availability-status1" style="font-size:12px;">
  </div>


 <div class="form-group">
    <label for="year"> Preference 1  </label>
    <select class="form-control" name="preference1" id="preference1" required="required">
    <option value="">Select Prefered slot 1</option>  
    <option value="Monday: 9:30 - 11:00" >Monday: 9:30 - 11:00 </option>
    <option value="Monday: 11:00 - 12:30" >Monday: 11:00 - 12:30 </option>
    <option value="Monday: 2:00 - 3:30" >Monday: 2:00 - 3:30 </option>
    <option value="Monday: 3:30 - 5:00" >Monday: 3:30 - 5:00 </option>
      <option value="Tuesday: 9:30 - 11:00" >Tuesday: 9:30 - 11:00 </option>
    <option value="Tuesday: 11:00 - 12:30" >Tuesday: 11:00 - 12:30 </option>
    <option value="Tuesay: 2:00 - 3:30" >Tuesday: 2:00 - 3:30 </option>
    <option value="Tuesday: 3:30 - 5:00" >Tuesday: 3:30 - 5:00 </option>
    <option value="Wednesday: 9:30 - 11:00" >Wednesday: 9:30 - 11:00 </option>
    <option value="Wednesday: 11:00 - 12:30" >Wednesday: 11:00 - 12:30 </option>
    <option value="Wednesday: 2:00 - 3:30" >Wednesday: 2:00 - 3:30 </option>
    <option value="Wednesday: 3:30 - 5:00" >Wednesday: 3:30 - 5:00 </option>
    <option value="Thursday: 9:30 - 11:00" >Thursday: 9:30 - 11:00 </option>
    <option value="Thursday: 11:00 - 12:30" >Thursday: 11:00 - 12:30 </option>
    <option value="Thursday: 2:00 - 3:30" >Thursday: 2:00 - 3:30 </option>
    <option value="Thursday: 3:30 - 5:00" >Thursday: 3:30 - 5:00 </option>
      <option value="Friday: 9:30 - 11:00" >Friday: 9:30 - 11:00 </option>
    <option value="Friday: 11:00 - 12:30" >Friday: 11:00 - 12:30 </option>
    <option value="Friday: 2:00 - 3:30" >Friday: 2:00 - 3:30 </option>
    <option value="Friday: 3:30 - 5:00" >Friday: 3:30 - 5:00 </option>
    <option value="Saturday: 9:30 - 11:00" >Saturday: 9:30 - 11:00 </option>
    <option value="Saturday: 11:00 - 12:30" >Saturday: 11:00 - 12:30 </option>
    <option value="Saturday: 2:00 - 3:30" >Saturday: 2:00 - 3:30 </option>
    <option value="Saturday: 3:30 - 5:00" >Saturday: 3:30 - 5:00 </option>
    </select>
  </div>
 <div class="form-group">
    <label for="year"> Preference 2 </label>
    <select class="form-control" name="preference2" id="preference2" required="required">
    <option value="">Select Prefered slot 2</option>  
    <option value="Monday: 9:30 - 11:00" >Monday: 9:30 - 11:00 </option>
    <option value="Monday: 11:00 - 12:30" >Monday: 11:00 - 12:30 </option>
    <option value="Monday: 2:00 - 3:30" >Monday: 2:00 - 3:30 </option>
    <option value="Monday: 3:30 - 5:00" >Monday: 3:30 - 5:00 </option>
      <option value="Tuesday: 9:30 - 11:00" >Tuesday: 9:30 - 11:00 </option>
    <option value="Tuesday: 11:00 - 12:30" >Tuesday: 11:00 - 12:30 </option>
    <option value="Tuesay: 2:00 - 3:30" >Tuesday: 2:00 - 3:30 </option>
    <option value="Tuesday: 3:30 - 5:00" >Tuesday: 3:30 - 5:00 </option>
    <option value="Wednesday: 9:30 - 11:00" >Wednesday: 9:30 - 11:00 </option>
    <option value="Wednesday: 11:00 - 12:30" >Wednesday: 11:00 - 12:30 </option>
    <option value="Wednesday: 2:00 - 3:30" >Wednesday: 2:00 - 3:30 </option>
    <option value="Wednesday: 3:30 - 5:00" >Wednesday: 3:30 - 5:00 </option>
    <option value="Thursday: 9:30 - 11:00" >Thursday: 9:30 - 11:00 </option>
    <option value="Thursday: 11:00 - 12:30" >Thursday: 11:00 - 12:30 </option>
    <option value="Thursday: 2:00 - 3:30" >Thursday: 2:00 - 3:30 </option>
    <option value="Thursday: 3:30 - 5:00" >Thursday: 3:30 - 5:00 </option>
      <option value="Friday: 9:30 - 11:00" >Friday: 9:30 - 11:00 </option>
    <option value="Friday: 11:00 - 12:30" >Friday: 11:00 - 12:30 </option>
    <option value="Friday: 2:00 - 3:30" >Friday: 2:00 - 3:30 </option>
    <option value="Friday: 3:30 - 5:00" >Friday: 3:30 - 5:00 </option>
    <option value="Saturday: 9:30 - 11:00" >Saturday: 9:30 - 11:00 </option>
    <option value="Saturday: 11:00 - 12:30" >Saturday: 11:00 - 12:30 </option>
    <option value="Saturday: 2:00 - 3:30" >Saturday: 2:00 - 3:30 </option>
    <option value="Saturday: 3:30 - 5:00" >Saturday: 3:30 - 5:00 </option>
    </select>
  </div>
 <div class="form-group">
    <label for="year"> Preference 3  </label>
    <select class="form-control" name="preference3" id="preference3" required="required">
    <option value="">Select Prefered slot 3</option>  
    <option value="Monday: 9:30 - 11:00" >Monday: 9:30 - 11:00 </option>
    <option value="Monday: 11:00 - 12:30" >Monday: 11:00 - 12:30 </option>
    <option value="Monday: 2:00 - 3:30" >Monday: 2:00 - 3:30 </option>
    <option value="Monday: 3:30 - 5:00" >Monday: 3:30 - 5:00 </option>
      <option value="Tuesday: 9:30 - 11:00" >Tuesday: 9:30 - 11:00 </option>
    <option value="Tuesday: 11:00 - 12:30" >Tuesday: 11:00 - 12:30 </option>
    <option value="Tuesay: 2:00 - 3:30" >Tuesday: 2:00 - 3:30 </option>
    <option value="Tuesday: 3:30 - 5:00" >Tuesday: 3:30 - 5:00 </option>
    <option value="Wednesday: 9:30 - 11:00" >Wednesday: 9:30 - 11:00 </option>
    <option value="Wednesday: 11:00 - 12:30" >Wednesday: 11:00 - 12:30 </option>
    <option value="Wednesday: 2:00 - 3:30" >Wednesday: 2:00 - 3:30 </option>
    <option value="Wednesday: 3:30 - 5:00" >Wednesday: 3:30 - 5:00 </option>
    <option value="Thursday: 9:30 - 11:00" >Thursday: 9:30 - 11:00 </option>
    <option value="Thursday: 11:00 - 12:30" >Thursday: 11:00 - 12:30 </option>
    <option value="Thursday: 2:00 - 3:30" >Thursday: 2:00 - 3:30 </option>
    <option value="Thursday: 3:30 - 5:00" >Thursday: 3:30 - 5:00 </option>
      <option value="Friday: 9:30 - 11:00" >Friday: 9:30 - 11:00 </option>
    <option value="Friday: 11:00 - 12:30" >Friday: 11:00 - 12:30 </option>
    <option value="Friday: 2:00 - 3:30" >Friday: 2:00 - 3:30 </option>
    <option value="Friday: 3:30 - 5:00" >Friday: 3:30 - 5:00 </option>
    <option value="Saturday: 9:30 - 11:00" >Saturday: 9:30 - 11:00 </option>
    <option value="Saturday: 11:00 - 12:30" >Saturday: 11:00 - 12:30 </option>
    <option value="Saturday: 2:00 - 3:30" >Saturday: 2:00 - 3:30 </option>
    <option value="Saturday: 3:30 - 5:00" >Saturday: 3:30 - 5:00 </option>
    </select>

    
  </div>
<?php } ?>

 

 <button type="submit" name="submit" id="submit" class="btn btn-default">Sumbit</button>
</form>
                            </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.11.1.js"></script>
    <script src="assets/js/bootstrap.js"></script>


</body>
</html>
<?php } ?>

