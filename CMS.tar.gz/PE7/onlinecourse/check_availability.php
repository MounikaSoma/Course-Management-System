<?php 
require_once("includes/config.php");
if(!empty($_POST["cid"])) {
	$cid= $_POST["cid"];
	
		$result =mysql_query("SELECT studentRegno FROM 	courseenrolls WHERE course='$cid'");
		$count=mysql_num_rows($result);
if($count>0)
{
echo "<span style='color:red'> Already Applied for this course.</span>";
 echo "<script>$('#submit').prop('disabled',true);</script>";
} 
}
if(!empty($_POST["cid"])) {
	$cid= $_POST["cid"];
	
		$result =mysql_query("SELECT * FROM 	courseenrolls WHERE course='$cid'");
		$count=mysql_num_rows($result);
		$result1 =mysql_query("SELECT noofSeats FROM course WHERE id='$cid'");
		$row=mysql_fetch_array($result1);
		$noofseat=$row['noofSeats'];
if($count>=$noofseat)
{
echo "<span style='color:red'> Seat not available for this course. All Seats Are full</span>";
 echo "<script>$('#submit').prop('disabled',true);</script>";
} 
}

?>
