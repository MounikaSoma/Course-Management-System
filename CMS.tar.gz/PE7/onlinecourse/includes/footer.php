<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2018 Course Management System | By : <a href="http://www.iiitb.ac.in/" target="_blank">IIITB students</a>
                </div>

            </div>
        </div>
    </footer>
