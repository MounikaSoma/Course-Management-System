<?php
session_start();
include('includes/config.php');
if(strlen($_SESSION['login'])==0)
    {   
header('location:addcourse.php');
}
else{


if(isset($_POST['submit']))
{
$studentregno=$_POST['studentregno'];
$studentname = $_POST['studentname'];
$addcourse=$_POST['addcourse'];
$dropcourse=$_POST['dropcourse'];
$year=$_POST['year'];
$sql=mysql_query("select * from course where id = $addcourse");
$row=mysql_fetch_array($sql);
$addprofid = $row['profid'];
$addcoursename = $row['courseName'];
$sql1=mysql_query("select * from course where id = $dropcourse");
$row1=mysql_fetch_array($sql1);
$dropprofid = $row1['profid'];
$dropcoursename = $row1['courseName'];

$ret=mysql_query("insert into adddropcourse(studentname,studentRegno,year,addcourseId,addcoursename,dropcourseId,dropcoursename,addprofid,dropprofid,addcourseflag,dropcourseflag) values('$studentname','$studentregno','$year','$addcourse','$addcoursename','$dropcourse','$dropcoursename','$addprofid','$dropprofid',0,0)");
if($ret)
{
$_SESSION['msg']="Submitted Successfully !!";
}
else
{
  $_SESSION['msg']="Error : Try Again!";
}
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Add/Drop</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>

<body>
<?php include('includes/header.php');?>
    <!-- LOGO HEADER END-->
<?php if($_SESSION['login']!="")
{
 include('includes/menubar.php');
}
 ?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Add Drop page </h1>
                    </div>
                </div>
                <div class="row" >
                  <div class="col-md-3"></div>
                    <div class="col-md-6">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                          Add/Drop
                        </div>
<font color="green" align="center"><?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></font>
<?php $sql=mysql_query("select * from students where StudentRegno='".$_SESSION['login']."'");
$cnt=1;
while($row=mysql_fetch_array($sql))
{ ?>

                        <div class="panel-body">
                       <form name="dept" method="post" enctype="multipart/form-data">
   <div class="form-group">
    <label for="studentname">Student Name  </label>
    <input type="text" class="form-control" id="studentname" name="studentname" value="<?php echo htmlentities($row['studentName']);?>"  />
  </div>

 <div class="form-group">
    <label for="studentregno">Student Reg No   </label>
    <input type="text" class="form-control" id="studentregno" name="studentregno" value="<?php echo htmlentities($row['StudentRegno']);?>"  placeholder="Student Reg no" readonly />
    
  </div>
 
 <div class="form-group">
    <label for="year"> Year   </label>
    <input type="number" class="form-control" id="year" name="year" value="<?php echo htmlentities($row['year']);?>"  placeholder="year" />
    
  </div>

<?php } ?>

 

<div class="form-group">
    <label for="AddCourse">Add course  </label>
    <select class="form-control" name="addcourse" id="addcourse" required="required">
   <option value="">Select Add Course</option>   
   <?php 
$sql=mysql_query("select * from course");
while($row=mysql_fetch_array($sql))
{
?>
<option value="<?php echo htmlentities($row['id']);?>"><?php echo htmlentities($row['courseName']);?></option>
<?php } ?>
    </select> 
    <span id="course-availability-status1" style="font-size:12px;">
  </div>
  
<div class="form-group">
    <label for="DropCourse">Drop Course </label>
    <select class="form-control" name="dropcourse" id="dropcourse" required="required">
   <option value="">Select Drop Course</option>   
   <?php 
$sql1=mysql_query("select * from courseenrolls where studentRegno ='".$_SESSION['login']."' ");
while($row1=mysql_fetch_array($sql1))
{
?>
<option value="<?php echo htmlentities($row1['courseId']);?>"><?php echo htmlentities($row1['coursename']);?></option>
<?php } ?>
    </select> 
    <span id="course-availability-status1" style="font-size:12px;">
  </div>
  



 <button type="submit" name="submit" id="submit" class="btn btn-default">Submit</button>
</form>
                            </div>
                            </div>
                    </div>
                  
                </div>

            </div>





        </div>
    </div>
  <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.11.1.js"></script>
    <script src="assets/js/bootstrap.js"></script>


</body>
</html>
<?php } ?>

