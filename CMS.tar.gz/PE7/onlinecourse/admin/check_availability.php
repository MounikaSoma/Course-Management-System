<?php 
require_once("includes/config.php");
if(!empty($_POST["email"])) {
	$email= $_POST["email"];
	
		$result =mysql_query("SELECT profEmail FROM faculty WHERE profEmail='$email'");
		$count=mysql_num_rows($result);
if($count>0)
{
echo "<span style='color:red'> Faculty with this Email is already Registered.</span>";
 echo "<script>$('#submit').prop('disabled',true);</script>";
} else{
	

}
}


?>
