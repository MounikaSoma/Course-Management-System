-- phpMy


 SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 30, 2018 at 07:28 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinecourse`
--

-- --------------------------------------------------------

--
-- Table structure for table `addcourse`
--

CREATE TABLE `addcourse` (
  `id` int(11) NOT NULL,
  `studentname` varchar(256) NOT NULL,
  `studentRegno` varchar(256) NOT NULL,
  `year` int(11) NOT NULL,
  `courseId` int(11) NOT NULL,
  `coursename` text NOT NULL,
  `profid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addcourse`
--

INSERT INTO `addcourse` (`id`, `studentname`, `studentRegno`, `year`, `courseId`, `coursename`, `profid`) VALUES
(14, 'Student', 'IMT2013002', 2013, 34, 'Networks', 4),
(15, 'Student', 'IMT2013002', 2013, 32, 'Social media Communication', 3),
(16, 'Student', 'IMT2013002', 2013, 35, 'khjkgihyu', 4),
(17, 'Student', 'IMT2013002', 2013, 36, 'Artificial Intelligence', 3);

-- --------------------------------------------------------

--
-- Table structure for table `adddropcourse`
--

CREATE TABLE `adddropcourse` (
  `id` int(100) NOT NULL,
  `studentname` varchar(256) NOT NULL,
  `studentRegno` varchar(255) NOT NULL,
  `year` int(100) NOT NULL,
  `addcourseId` int(100) NOT NULL,
  `addcoursename` varchar(255) NOT NULL,
  `dropcourseId` int(100) NOT NULL,
  `dropcoursename` varchar(255) NOT NULL,
  `addprofId` int(10) NOT NULL,
  `dropprofid` int(100) NOT NULL,
  `addcourseflag` int(11) NOT NULL,
  `dropcourseflag` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adddropcourse`
--

INSERT INTO `adddropcourse` (`id`, `studentname`, `studentRegno`, `year`, `addcourseId`, `addcoursename`, `dropcourseId`, `dropcoursename`, `addprofId`, `dropprofid`, `addcourseflag`, `dropcourseflag`) VALUES
(3, 'Student', 'IMT2013002', 2013, 33, 'techno economics', 36, 'Artificial Intelligence', 3, 3, 1, -1),
(4, 'Student', 'IMT2013002', 2013, 32, 'Social media Communication', 35, 'khjkgihyu', 3, 4, -1, 1),
(5, 'Student', 'IMT2013002', 2013, 33, 'techno economics', 33, 'techno economics', 3, 3, 1, 1),
(6, 'Student', 'IMT2013004', 2013, 33, 'techno economics', 34, 'Networks', 3, 4, 1, 1),
(7, 'Student', 'IMT2013004', 2013, 36, 'Artificial Intelligence', 32, 'Social media Communication', 3, 3, 1, 0),
(8, 'Student', 'IMT2013004', 2013, 34, 'Networks', 33, 'techno economics', 4, 3, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `creationDate`, `updationDate`) VALUES
(1, 'admin', '5c428d8875d2948607f3e3fe134d71b4', '2017-01-24 16:21:18', '09-02-2017 11:33:39 PM');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `courseCode` varchar(255) NOT NULL,
  `courseName` varchar(255) NOT NULL,
  `courseDescription` varchar(256) DEFAULT NULL,
  `Prerequisites` varchar(256) DEFAULT 'None',
  `semester` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `credits` int(11) NOT NULL,
  `noofSeats` int(11) NOT NULL,
  `commitflag` tinyint(1) NOT NULL DEFAULT '0',
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) NOT NULL,
  `profid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `courseCode`, `courseName`, `courseDescription`, `Prerequisites`, `semester`, `year`, `credits`, `noofSeats`, `commitflag`, `creationDate`, `updationDate`, `profid`) VALUES
(32, '1312', 'Social media Communication', 'zjnvlnvl', 'None', 3, 2019, 4, 32, 1, '2018-03-28 16:58:52', '31-03-2018 11:53:53 PM', 3),
(33, '1222', 'techno economics', 'r3iuegtfwq', 'None', 3, 2016, 3, 5, 1, '2018-03-31 18:21:36', '', 3),
(34, 'NC101', 'Networks', 'This is about networks', 'None', 5, 2018, 4, 60, 1, '2018-04-01 12:34:07', '', 4),
(35, '97', 'khjkgihyu', 'iwhde', 'None', 3, 2014, 2, 23, 1, '2018-04-01 12:35:56', '', 4),
(36, '5453', 'Artificial Intelligence', 'Its  a nice course', 'Machine Learning', 2, 2015, 4, 20, 0, '2018-04-03 10:10:27', '', 3);

-- --------------------------------------------------------

--
-- Table structure for table `coursecomments`
--

CREATE TABLE `coursecomments` (
  `id` int(11) NOT NULL,
  `profname` varchar(256) NOT NULL,
  `courseId` int(11) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coursecomments`
--

INSERT INTO `coursecomments` (`id`, `profname`, `courseId`, `comment`) VALUES
(4, 'ltj', 1, 'This is a gud course'),
(5, 'das', 1, 'felkwegwu'),
(6, 'ltj', 35, 'hello..hw do u do?'),
(7, 'ltj', 34, 'hiqwffew'),
(8, 'das', 32, 'hidwqufb'),
(9, 'dinesh', 35, 'dwkqhefyugrthh'),
(10, 'ltj', 35, 'This is a good course');

-- --------------------------------------------------------

--
-- Table structure for table `courseenrolls`
--

CREATE TABLE `courseenrolls` (
  `id` int(11) NOT NULL,
  `studentRegno` varchar(255) NOT NULL,
  `year` int(11) NOT NULL,
  `courseId` int(11) NOT NULL,
  `coursename` varchar(256) NOT NULL,
  `addcourseid` int(11) NOT NULL,
  `enrollDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courseenrolls`
--

INSERT INTO `courseenrolls` (`id`, `studentRegno`, `year`, `courseId`, `coursename`, `addcourseid`, `enrollDate`) VALUES
(64, 'IMT2013002', 2013, 36, 'Artificial Intelligence', 0, '2018-04-07 18:51:57'),
(65, 'IMT2013002', 2013, 35, 'khjkgihyu', 0, '2018-04-12 11:11:18'),
(68, 'IMT2013004', 2013, 32, 'Social media Communication', 0, '2018-04-12 13:08:07'),
(77, 'IMT2013004', 2013, 33, 'techno economics', 0, '2018-04-12 13:39:07'),
(79, 'IMT2013004', 2013, 33, 'techno economics', 0, '2018-04-13 09:24:19'),
(80, 'IMT2013002', 2013, 32, 'Social media Communication', 0, '2018-04-18 12:24:56'),
(81, 'IMT2013002', 2013, 32, 'Social media Communication', 0, '2018-04-18 12:33:10'),
(83, 'IMT2013004', 2013, 33, 'techno economics', 0, '2018-04-25 06:40:20');

-- --------------------------------------------------------

--
-- Table structure for table `courseprof`
--

CREATE TABLE `courseprof` (
  `id` int(11) NOT NULL,
  `courseid` int(11) NOT NULL,
  `profid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courseprof`
--

INSERT INTO `courseprof` (`id`, `courseid`, `profid`) VALUES
(17, 27, 3),
(18, 27, 3),
(19, 32, 3),
(20, 33, 3),
(21, 34, 4),
(22, 35, 4),
(23, 36, 3),
(24, 0, 4),
(25, 0, 4),
(26, 0, 4),
(27, 0, 4),
(28, 0, 4),
(29, 0, 4),
(30, 0, 4),
(31, 0, 4),
(32, 37, 4),
(33, 37, 4),
(34, 39, 4),
(35, 39, 4);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `department` varchar(255) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `id` int(11) NOT NULL,
  `profName` varchar(255) NOT NULL,
  `profEmail` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `profName`, `profEmail`, `password`, `creationDate`, `updationDate`) VALUES
(3, 'ltj', 'ltj@gmail.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', '2018-03-20 18:03:40', ''),
(4, 'das', 'das@gmail.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', '2018-03-20 18:03:56', ''),
(5, 'dinesh', 'dinesh@iiitb.org', 'd8578edf8458ce06fbc5bb76a58c5ca4', '2018-04-01 12:47:38', ''),
(6, 'fg4lkjg', 'ldwfe', '7f3324c4fe46a313c3bca44483c1f993', '2018-04-30 16:45:20', '');

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE `level` (
  `id` int(11) NOT NULL,
  `level` varchar(255) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `id` int(11) NOT NULL,
  `semester` varchar(255) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`id`, `semester`, `creationDate`, `updationDate`) VALUES
(3, 'First Sem', '2017-02-09 18:47:14', ''),
(4, 'Second sem', '2017-02-09 18:47:59', ''),
(5, 'Third Sem', '2017-02-09 18:48:04', '');

-- --------------------------------------------------------

--
-- Table structure for table `slots`
--

CREATE TABLE `slots` (
  `id` int(11) NOT NULL,
  `profid` int(10) NOT NULL,
  `coursename` varchar(255) NOT NULL,
  `courseid` int(10) NOT NULL,
  `preference1` varchar(255) NOT NULL,
  `preference2` varchar(255) NOT NULL,
  `preference3` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slots`
--

INSERT INTO `slots` (`id`, `profid`, `coursename`, `courseid`, `preference1`, `preference2`, `preference3`) VALUES
(1, 3, 'Social media Communication', 32, 'Monday: 9:30-11:00', 'Tuesday: 11:00 - 12:30', 'Friday: 11:00 - 12:30'),
(2, 3, 'techno economics', 33, 'Monday: 9:30 - 11:00', 'Thursday: 9:30 - 11:00', 'Thursday: 2:00 - 3:30'),
(3, 3, 'Artificial Intelligence', 36, 'Saturday: 9:30 - 11:00', 'Thursday: 9:30 - 11:00', 'Tuesday: 3:30 - 5:00'),
(4, 4, 'Networks', 34, 'Monday: 11:00 - 12:30', 'Wednesday: 2:00 - 3:30', 'Friday: 9:30 - 11:00');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `StudentRegno` varchar(255) NOT NULL,
  `StudentEmail` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `studentName` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `semester` varchar(255) NOT NULL,
  `cgpa` decimal(10,2) NOT NULL,
  `creationdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`StudentRegno`, `StudentEmail`, `password`, `studentName`, `year`, `department`, `semester`, `cgpa`, `creationdate`, `updationDate`) VALUES
('IMT2013001', 'IMT2013001@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2013', 'IT', '1', '0.00', '2018-03-31 16:28:45', ''),
('IMT2013002', 'IMT2013002@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2013', 'IT', '1', '0.00', '2018-03-31 16:28:45', ''),
('IMT2013003', 'somasri.mounika@iiitb.org', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Mounika', '2013', 'IT', '1', '3.12', '2018-03-31 16:28:45', ''),
('IMT2013004', 'IMT2013004@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2013', 'IT', '1', '0.00', '2018-03-31 16:28:45', ''),
('IMT2014001', 'student1@iiitb.org', 'qwerty', 'Student1', '2014', 'IT', '2', '3.40', '2018-03-21 18:13:49', ''),
('IMT2014002', 'student2@iiitb.org', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student2', '2014', 'IT', '2', '0.00', '2018-03-21 19:18:04', ''),
('IMT2019001', 'IMT2019001@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:35', ''),
('IMT2019002', 'IMT2019002@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:35', ''),
('IMT2019003', 'IMT2019003@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:35', ''),
('IMT2019004', 'IMT2019004@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:35', ''),
('IMT2019005', 'IMT2019005@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:35', ''),
('IMT2019006', 'IMT2019006@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:35', ''),
('IMT2019007', 'IMT2019007@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:35', ''),
('IMT2019008', 'IMT2019008@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:35', ''),
('IMT2019009', 'IMT2019009@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:35', ''),
('IMT2019011', 'IMT2019011@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:35', ''),
('IMT2019012', 'IMT2019012@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:35', ''),
('IMT2019013', 'IMT2019013@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:35', ''),
('IMT2019014', 'IMT2019014@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:35', ''),
('IMT2019015', 'IMT2019015@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:36', ''),
('IMT2019016', 'IMT2019016@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:36', ''),
('IMT2019017', 'IMT2019017@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:36', ''),
('IMT2019018', 'IMT2019018@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:36', ''),
('IMT2019019', 'IMT2019019@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:36', ''),
('IMT2019020', 'IMT2019020@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:36', ''),
('IMT2019021', 'IMT2019021@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:36', ''),
('IMT2019022', 'IMT2019022@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:36', ''),
('IMT2019023', 'IMT2019023@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:36', ''),
('IMT2019024', 'IMT2019024@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:36', ''),
('IMT2019025', 'IMT2019025@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:36', ''),
('IMT2019026', 'IMT2019026@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:36', ''),
('IMT2019027', 'IMT2019027@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:36', ''),
('IMT2019028', 'IMT2019028@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:36', ''),
('IMT2019029', 'IMT2019029@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:36', ''),
('IMT2019030', 'IMT2019030@iiitb.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Student', '2019', 'IT', '1', '0.00', '2018-04-04 08:13:36', '');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `studentRegno` varchar(255) NOT NULL,
  `userip` binary(16) NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `logout` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `studentRegno`, `userip`, `loginTime`, `logout`, `status`) VALUES
(1, 'IMT2014002', 0x3132372e302e302e3100000000000000, '2018-03-22 10:12:41', '', 1),
(2, 'IMT2014002', 0x3132372e302e302e3100000000000000, '2018-03-22 10:14:14', '', 1),
(3, 'IMt2014002', 0x3132372e302e302e3100000000000000, '2018-03-22 10:15:04', '22-03-2018 03:46:07 PM', 1),
(4, 'IMT2014002', 0x3132372e302e302e3100000000000000, '2018-03-22 10:24:14', '22-03-2018 03:59:49 PM', 1),
(5, 'IMT2014002', 0x3132372e302e302e3100000000000000, '2018-03-31 15:44:37', '31-03-2018 09:42:18 PM', 1),
(6, 'IMT2013003', 0x3132372e302e302e3100000000000000, '2018-03-31 16:29:01', '31-03-2018 11:18:49 PM', 1),
(7, 'IMT2019001', 0x3132372e302e302e3100000000000000, '2018-04-04 08:13:52', '', 1),
(8, 'IMT2013001', 0x3132372e302e302e3100000000000000, '2018-04-07 12:23:42', '', 1),
(9, 'IMT2013001', 0x3132372e302e302e3100000000000000, '2018-04-07 14:09:12', '07-04-2018 10:55:55 PM', 1),
(10, 'IMT2013003', 0x3132372e302e302e3100000000000000, '2018-04-07 17:26:02', '', 1),
(11, 'IMT2013001', 0x3132372e302e302e3100000000000000, '2018-04-07 17:43:20', '07-04-2018 11:14:06 PM', 1),
(12, 'IMT2013003', 0x3132372e302e302e3100000000000000, '2018-04-07 17:44:13', '', 1),
(13, 'IMT2013002', 0x3132372e302e302e3100000000000000, '2018-04-07 18:25:42', '', 1),
(14, 'IMT2013003', 0x3132372e302e302e3100000000000000, '2018-04-07 18:26:20', '', 1),
(15, 'IMT2013003', 0x3132372e302e302e3100000000000000, '2018-04-07 18:27:35', '', 1),
(16, 'IMT2013003', 0x3132372e302e302e3100000000000000, '2018-04-07 18:28:37', '', 1),
(17, 'IMT2013002', 0x3132372e302e302e3100000000000000, '2018-04-07 18:32:09', '', 1),
(18, 'IMT2013002', 0x3132372e302e302e3100000000000000, '2018-04-07 18:35:29', '', 1),
(19, 'IMT2013002', 0x3132372e302e302e3100000000000000, '2018-04-07 18:44:37', '', 1),
(20, 'IMT2013002', 0x3132372e302e302e3100000000000000, '2018-04-07 18:48:14', '', 1),
(21, 'IMT2013002', 0x3132372e302e302e3100000000000000, '2018-04-07 18:51:04', '', 1),
(22, 'IMT2013002', 0x3132372e302e302e3100000000000000, '2018-04-07 18:52:09', '', 1),
(23, 'IMT2013001', 0x3132372e302e302e3100000000000000, '2018-04-08 14:09:14', '', 1),
(24, 'IMT2013002', 0x3132372e302e302e3100000000000000, '2018-04-08 16:25:04', '08-04-2018 10:00:07 PM', 1),
(25, 'IMT2013002', 0x3132372e302e302e3100000000000000, '2018-04-08 16:53:45', '08-04-2018 10:27:07 PM', 1),
(26, 'IMT2013001', 0x3132372e302e302e3100000000000000, '2018-04-08 17:01:51', '', 1),
(27, 'IMT2013002', 0x3132372e302e302e3100000000000000, '2018-04-12 10:16:54', '12-04-2018 03:49:47 PM', 1),
(28, 'IMT2013002', 0x3132372e302e302e3100000000000000, '2018-04-12 10:27:35', '12-04-2018 04:40:54 PM', 1),
(29, 'IMT2013002', 0x3132372e302e302e3100000000000000, '2018-04-12 11:11:07', '12-04-2018 04:42:49 PM', 1),
(30, 'IMT2013004', 0x3132372e302e302e3100000000000000, '2018-04-12 13:07:55', '12-04-2018 06:39:16 PM', 1),
(31, 'IMT2013004', 0x3132372e302e302e3100000000000000, '2018-04-12 13:39:43', '12-04-2018 07:10:13 PM', 1),
(32, 'IMT2013004', 0x3132372e302e302e3100000000000000, '2018-04-13 09:15:39', '', 1),
(33, 'IMT2013002', 0x3132372e302e302e3100000000000000, '2018-04-18 12:24:43', '18-04-2018 06:09:53 PM', 1),
(34, 'IMT2013002', 0x3132372e302e302e3100000000000000, '2018-04-18 12:59:54', '', 1),
(35, 'IMT2013002', 0x3132372e302e302e3100000000000000, '2018-04-25 06:29:26', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `year`
--

CREATE TABLE `year` (
  `id` int(11) NOT NULL,
  `year` varchar(255) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addcourse`
--
ALTER TABLE `addcourse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adddropcourse`
--
ALTER TABLE `adddropcourse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coursecomments`
--
ALTER TABLE `coursecomments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courseenrolls`
--
ALTER TABLE `courseenrolls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courseprof`
--
ALTER TABLE `courseprof`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `level`
--
ALTER TABLE `level`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slots`
--
ALTER TABLE `slots`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`StudentRegno`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `year`
--
ALTER TABLE `year`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addcourse`
--
ALTER TABLE `addcourse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `adddropcourse`
--
ALTER TABLE `adddropcourse`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `coursecomments`
--
ALTER TABLE `coursecomments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `courseenrolls`
--
ALTER TABLE `courseenrolls`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;
--
-- AUTO_INCREMENT for table `courseprof`
--
ALTER TABLE `courseprof`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `level`
--
ALTER TABLE `level`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `slots`
--
ALTER TABLE `slots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `year`
--
ALTER TABLE `year`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
