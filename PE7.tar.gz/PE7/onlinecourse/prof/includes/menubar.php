<section class="menu-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                            <li><a href="change-password.php">Dashboard</a></li>
                             <li><a href="course.php">Create Course</a></li>
 				<li><a href="mycourses.php">My Courses</a></li>
 				<li><a href="courseslist.php">Courses</a></li> 
  				<li><a href="addrequests.php">Add requests</a></li>
 				<li><a href="droprequests.php">Drop requests</a></li>                           
                            <li><a href="logout.php">Logout</a></li>

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
