<?php
session_start();
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{
if(isset($_POST['filter'])){
$profid = $_POST['filter'];
echo $profid;
echo "hii";
}
?>

<!DOCTYPE html> 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Requests</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>

<body>
<?php include('includes/header.php');?>
    <!-- LOGO HEADER END-->
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php');
}

 ?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
              <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Requests  </h1>
                    </div>
                </div>
                <div class="row" >
                  <div class="col-md-3"></div>
                    <div class="col-md-6">
                       
                        
<font color="green" align="center"><?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></font>


                    </div>
                  
                </div>
                
                <div class="col-md-12">
                    <!--    Bordered Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Slots from the professors
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Student Name</th>
                                            <th>Student Roll No</th>
                                            <th>Add Course </th>
                                            <th>Add Course Professor </th>
                                             <th>Drop Course</th>
                                             <th>Drop Course Professor</th>
                                             <th>Add Course Accepted/Rejected</th>
                                             <th>Drop Course Accepted/Rejected</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$sql=mysql_query("select * from adddropcourse where addprofId='$profid' or dropprofId='$profid' ");
$cnt=1;
while($row=mysql_fetch_array($sql))
{
?>


                                        <tr>
                                            <td><?php echo $cnt;?></td>
                                            <td><?php echo htmlentities($row['studentname']);?></td>
                                            <td><?php echo htmlentities($row['studentRegno']);?></td>
                                             <td><?php echo htmlentities($row['addcoursename']);?></td>
                                              <?php
                                            $prid = $row['addprofId'];
                                            $sql1=mysql_query("select * from faculty where id = '$prid'");
					    $row1=mysql_fetch_array($sql1)
                                            ?>
                                            <td><?php echo htmlentities($row1['profName']);?></td>
                                            
                                            
                                            <td><?php echo htmlentities($row['dropcoursename']);?></td>
                                            <?php
                                             $pid = $row['dropprofid'];
                                            $sql2=mysql_query("select * from faculty where id = '$pid'");
					    $row2=mysql_fetch_array($sql2)
                                            ?>
                                            <td><?php echo htmlentities($row2['profName']);?></td>            
                                  
                                            <td><?php if($row['addcourseflag']==0) {echo htmlentities('Proccessing....');} else if($row['addcourseflag']==1) {echo htmlentities('Accepted');} else {echo htmlentities('Rejected');}  ?></td>
                                            <td><?php if($row['dropcourseflag']==0) {echo htmlentities('Proccessing....');} else if($row['dropcourseflag']==1) {echo htmlentities('Accepted');} else {echo htmlentities('Rejected');}  ?></td>
                                           
<?php 
$cnt++;
} ?>
             
                                    </tbody>
                                    
                            </div>
                            
                        </div>
                        
                    </div>
                    
                    
                </div>
      
                
            </div> 

                                             
    
    <!-- CONTENT-WRAPPER SECTION END-->
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <div class="form-group">
    <label for="Course">Professor name </label>
    <select class="form-control" name="profid" id="profid" required="required">
   <option value="">Select professor name</option>   
   <?php 
$sql=mysql_query("select * from faculty");
while($row=mysql_fetch_array($sql))
{
?>
<option value="<?php echo htmlentities($row['id']);?>"><?php echo htmlentities($row['profName']);?></option>

 
<?php } ?>

    </select> 
    
<button type="submit" name="filter" id="filter" class="btn btn-default">Apply filter</button>
  
  </div>
    
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    
</body>

</html>

<?php } ?>

